const sidebar = document.querySelector(".sidebar");
const openMenu = document.querySelector(".openMenu");
const close = document.querySelector(".close");

openMenu.addEventListener("click", (event) => {
  sidebar.classList.toggle("hidden");
});

close.addEventListener("click", (event) => {
  sidebar.classList.toggle("hidden");
});

document.addEventListener("keyup", (event) => {
  console.log(event.key);

  if (event.key === "Escape") {
    sidebar.classList.add("hidden");
  }
});

class Person {}
